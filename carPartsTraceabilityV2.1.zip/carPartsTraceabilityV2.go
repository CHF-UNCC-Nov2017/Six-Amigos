/*
Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.
*/

// ====CHAINCODE EXECUTION SAMPLES (BCS REST API) ==================
/*
#TEST transaction / Init ledger

curl -H "Content-type:application/json" -X POST http://localhost:3100/bcsgw/rest/v1/transaction/invocation -d '{"channel":"channel1","chaincode":"vehiclenet","method":"initLedgerB","args":["ser1234"],"chaincodeVer":"v1"}'
curl -H "Content-type:application/json" -X POST http://localhost:3100/bcsgw/rest/v1/transaction/invocation -d '{"channel":"channel1","chaincode":"vehiclenet","method":"initLedgerC","args":["ser1234"],"chaincodeVer":"v1"}'
curl -H "Content-type:application/json" -X POST http://localhost:3100/bcsgw/rest/v1/transaction/invocation -d '{"channel":"channel1","chaincode":"vehiclenet","method":"initLedgerD","args":["ser1234"],"chaincodeVer":"v1"}'

# TEST transaction / Add Car Part

curl -H "Content-type:application/json" -X POST http://localhost:3100/bcsgw/rest/v1/transaction/invocation -d '{"channel":"channel1","chaincode":"vehiclenet","method":"initVehiclePart","args":["ser1234", "tata", "1502688979", "airbag 2020", "mazda", "false", "1502688979"],"chaincodeVer":"v1"}'
curl -H "Content-type:application/json" -X POST http://localhost:3100/bcsgw/rest/v1/transaction/invocation -d '{"channel":"channel1","chaincode":"vehiclenet","method":"initVehiclePart","args":["ser1235", "tata", "1502688979", "airbag 2020", "mercedes", "false", "1502688979"],"chaincodeVer":"v1"}'
curl -H "Content-type:application/json" -X POST http://localhost:3100/bcsgw/rest/v1/transaction/invocation -d '{"channel":"channel1","chaincode":"vehiclenet","method":"initVehiclePart","args":["ser1236", "tata", "1502688979", "airbag 2020", "toyota", "false", "15026889790"],"chaincodeVer":"v1"}'
curl -H "Content-type:application/json" -X POST http://localhost:3100/bcsgw/rest/v1/transaction/invocation -d '{"channel":"channel1","chaincode":"vehiclenet","method":"initVehiclePart","args":["ser1237", "tata", "1502688979", "airbag 5000", "mazda", "false", "1502688979"],"chaincodeVer":"v1"}'
curl -H "Content-type:application/json" -X POST http://localhost:3100/bcsgw/rest/v1/transaction/invocation -d '{"channel":"channel1","chaincode":"vehiclenet","method":"initVehiclePart","args":["ser1238", "tata", "1502688979", "airbag 5000", "mercedes", "false", "1502688979"],"chaincodeVer":"v1"}'
curl -H "Content-type:application/json" -X POST http://localhost:3100/bcsgw/rest/v1/transaction/invocation -d '{"channel":"channel1","chaincode":"vehiclenet","method":"initVehiclePart","args":["ser1239", "tata", "1502688979", "airbag 5000", "toyota", "false", "15026889790"],"chaincodeVer":"v1"}'

# TEST transaction / Add Car

curl -H "Content-type:application/json" -X POST http://localhost:3100/bcsgw/rest/v1/transaction/invocation -d '{"channel":"channel1","chaincode":"vehiclenet","method":"initVehicle","args":["mer1000001", "mercedes", "c class", "1502688979", "ser1234", "mercedes", "false", "1502688979"],"chaincodeVer":"v1"}'
curl -H "Content-type:application/json" -X POST http://localhost:3100/bcsgw/rest/v1/transaction/invocation -d '{"channel":"channel1","chaincode":"vehiclenet","method":"initVehicle","args":["maz1000001", "mazda", "mazda 6", "1502688979", "ser1235", "mazda", "false", "1502688979"],"chaincodeVer":"v1"}'
curl -H "Content-type:application/json" -X POST http://localhost:3100/bcsgw/rest/v1/transaction/invocation -d '{"channel":"channel1","chaincode":"vehiclenet","method":"initVehicle","args":["ren1000001", "renault", "megan", "1502688979", "ser1236", "renault", "false", "1502688979"],"chaincodeVer":"v1"}'
curl -H "Content-type:application/json" -X POST http://localhost:3100/bcsgw/rest/v1/transaction/invocation -d '{"channel":"channel1","chaincode":"vehiclenet","method":"initVehicle","args":["ford1000001", "ford", "mustang", "1502688979", "ser1237", "ford", "false", "1502688979"],"chaincodeVer":"v1"}'

# TEST query / Populated database

curl -H "Content-type:application/json" -X POST http://localhost:3100/bcsgw/rest/v1/transaction/query -d '{"channel":"channel1","chaincode":"vehiclenet","method":"readVehiclePart","args":["ser1234"],"chaincodeVer":"v1"}'
curl -H "Content-type:application/json" -X POST http://localhost:3100/bcsgw/rest/v1/transaction/query -d '{"channel":"channel1","chaincode":"vehiclenet","method":"readVehicle","args":["mer1000001"],"chaincodeVer":"v1"}'

# TEST transaction / Transfer ownership

curl -H "Content-type:application/json" -X POST http://localhost:3100/bcsgw/rest/v1/transaction/invocation -d '{"channel":"channel1","chaincode":"vehiclenet","method":"transferVehiclePart","args":["ser1234", "mercedes"],"chaincodeVer":"v1"}'
curl -H "Content-type:application/json" -X POST http://localhost:3100/bcsgw/rest/v1/transaction/invocation -d '{"channel":"channel1","chaincode":"vehiclenet","method":"transferVehicle","args":["mer1000001", "mercedes los angeles"],"chaincodeVer":"v1"}'

# TEST query / Get History

curl -H "Content-type:application/json" -X POST http://localhost:3100/bcsgw/rest/v1/transaction/query -d '{"channel":"channel1","chaincode":"vehiclenet","method":"getHistoryForRecord","args":["ser1234"],"chaincodeVer":"v1"}'
curl -H "Content-type:application/json" -X POST http://localhost:3100/bcsgw/rest/v1/transaction/query -d '{"channel":"channel1","chaincode":"vehiclenet","method":"getHistoryForRecord","args":["mer1000001"],"chaincodeVer":"v1"}'

# TEST transaction / delete records

curl -H "Content-type:application/json" -X POST http://localhost:3100/bcsgw/rest/v1/transaction/invocation -d '{"channel":"channel1","chaincode":"vehiclenet","method":"deleteVehiclePart","args":["ser1235"],"chaincodeVer":"v1"}'
curl -H "Content-type:application/json" -X POST http://localhost:3100/bcsgw/rest/v1/transaction/invocation -d '{"channel":"channel1","chaincode":"vehiclenet","method":"deleteVehicle","args":["maz1000001"],"chaincodeVer":"v1"}'

# TEST transaction / Recall Part

curl -H "Content-type:application/json" -X POST http://localhost:3100/bcsgw/{"channel":"channel1","chaincode":"vehiclenet","method":"setPartRecallState","args":["abg1234",true],"chaincodeVer":"v3"}'



CRYPTO
#Sign
go run cryptoHOL.go -s welcome

#Verify
go run cryptoHOL.go -v welcome 23465785510810132448457841429882907809251724155505686786147550387897 10848776947772665661803987914449872333300709981875993855742805426849
*/

// Index for chaincodeid, docType, owner, size (descending order).
// Note that docType, owner and size fields must be prefixed with the "data" wrapper
// chaincodeid must be added for all queries
//
// Definition for use with Fauxton interface
// {"index":{"fields":[{"data.size":"desc"},{"chaincodeid":"desc"},{"data.docType":"desc"},{"data.owner":"desc"}]},"ddoc":"indexSizeSortDoc", "name":"indexSizeSortDesc","type":"json"}
//
// example curl definition for use with command line
// curl -i -X POST -H "Content-Type: application/json" -d "{\"index\":{\"fields\":[{\"data.size\":\"desc\"},{\"chaincodeid\":\"desc\"},{\"data.docType\":\"desc\"},{\"data.owner\":\"desc\"}]},\"ddoc\":\"indexSizeSortDoc\", \"name\":\"indexSizeSortDesc\",\"type\":\"json\"}" http://hostname:port/channelNameGoesHere/_index

// Rich Query with index design doc and index name specified (Only supported if CouchDB is used as state database):
//   peer chaincode query -C channelNameGoesHere -n vehicleParts -c '{"Args":["queryVehiclePart","{\"selector\":{\"docType\":\"vehiclePart\",\"owner\":\"mercedes\"}, \"use_index\":[\"_design/indexOwnerDoc\", \"indexOwner\"]}"]}'

// Rich Query with index design doc specified only (Only supported if CouchDB is used as state database):
//   peer chaincode query -C channelNameGoesHere -n vehicleParts -c '{"Args":["queryVehiclePart","{\"selector\":{\"docType\":{\"$eq\":\"vehiclePart\"},\"owner\":{\"$eq\":\"mercedes\"},\"assemblyDate\":{\"$gt\":1502688979}},\"fields\":[\"docType\",\"owner\",\"assemblyDate\"],\"sort\":[{\"assemblyDate\":\"desc\"}],\"use_index\":\"_design/indexSizeSortDoc\"}"]}'

package main

import (
	"bytes"
	"crypto/ecdsa"
	"crypto/x509"
	"encoding/json"
	"fmt"
	"math/big"
	"strconv"
	"strings"
	"time"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	pb "github.com/hyperledger/fabric/protos/peer"
)

// AutoTraceChaincode example simple Chaincode implementation
type AutoTraceChaincode struct {
}

// @MODIFY_HERE add recall fields to vehiclePart JSON object
type user struct {
	ObjectType   string `json:"docType"` //docType is used to distinguish the various types of objects in state database
	name string `json:"name"`
	userId	  	string `json:"id"` //the fieldtags are needed to keep case from bouncing around
	emailId    	string `json:"emailId"`
	creditScore int    `json:"creditScore"`
	latitude    string `json:"latitude"`
	longitude	string	`json:"longitude"`
	contactNumber	string `json:"contactNumber"`
	rating	string `json:"rating"`
}

// @MODIFY_HERE add recall fields to vehiclePart JSON object
type item struct {
	ObjectType   string `json:"docType"` //docType is used to distinguish the various types of objects in state database
	name string `json:"name"`
	id    string `json:"id"` //the fieldtags are needed to keep case from bouncing around
	type string    `json:"type"`
	weight float64    `json:"weight"`
	brand string    `json:"brand"`
	model string    `json:"model"`
	manufactureYear int    `json:"manufactureYear"`
	lenderId string    `json:"lenderId"`
	renterId string    `json:"renterId"`
	lat float64    `json:"lat"`
	lang float64    `json:"lang"`
	isActive bool    `json:"isActive"`
	rating float64    `json:"rating"`
	pricePerday float64    `json:"pricePerday"`
	imageHash	string		`json:"imageHash"`
	timeRented	int		`json:"timeRented"`
	timeReturned	int	`json:"timeReturned"`
	currentTransactionId      string `json:"currentTransactionId"`
}

// @MODIFY_HERE add recall fields to vehicle JSON object
type transaction struct {
	ObjectType         string `json:"docType"`       //docType is used to distinguish the various types of objects in state database
	transactionId      string `json:"transactionId"` //the fieldtags are needed to keep case from bouncing around
	renterId       string `json:"renterId"`
	lenderId              string `json:"lenderId"`
	itemId       string    `json:"itemId"`
	startTime uint `json:"startTime"`
	endTime     uint `json:"endTime"`
	actualReturnTime uint `json:"actualReturnTime"`
	beforeImageURL    string   `json:"beforeImageURL"`     // to be added at workshop
	afterImageURL    string   `json:"afterImageURL"`
	transactionCost 	float64		`json:"transactionCost"`
	finalTransactionCost 	float64		`json:"finalTransactionCost"`
	isLeaseBroken		bool	`json:"isLeaseBroken"`
	isInsuranceOpted		bool	`json:"isInsuranceOpted"`
	extraCost         float32    `json:"extraCost"` // to be added at workshop
}

// ===================================================================================
// Main
// ===================================================================================
func main() {
	err := shim.Start(new(AutoTraceChaincode))
	if err != nil {
		fmt.Printf("Error starting Parts Trace chaincode: %s", err)
	}
}

// Init initializes chaincode
// ===========================
func (t *AutoTraceChaincode) Init(stub shim.ChaincodeStubInterface) pb.Response {
	fmt.Println("Building ledger initial state")
	// ==== Only enable this to be executed once by checking for a pre-installed serial number ====
	vehiclePartAsBytes, err := stub.GetState("abg1234")
	if vehiclePartAsBytes != nil {
		fmt.Println("ledger state previously set")
		return shim.Success(nil)
	}

	message, err := t.initLedgerA(stub)
	if err != nil {
		return shim.Error(err.Error())
	} else if message != "" {
		return shim.Error("Failed to run initLedgerA:" + message)
	}

	// DO NOT REMOVE COMMENT - BELOW WILL FAIL TO EXECUTE FOR REASONS EXPOLAINED IN HOL
	/*message, err = t.initLedgerB(stub)
	if err != nil {
		return shim.Error(err.Error())
	} else if message != "" {
		return shim.Error("Failed to run initLedgerB:" + message)
	}

	message, err = t.initLedgerC(stub)
	if err != nil {
		return shim.Error(err.Error())
	} else if message != "" {
		return shim.Error("Failed to run initLedgerC:" + message)
	}*/

	fmt.Println("ledger initial state set")
	return shim.Success(nil)
}

// Invoke - Our entry point for Invocations
// ========================================
func (t *AutoTraceChaincode) Invoke(stub shim .ChaincodeStubInterface) pb.Response {
	function, args := stub.GetFunctionAndParameters()
	fmt.Println("invoke is running " + function)

	// Handle different functions
	if function == "initUser" { //create a new vehiclePart
		return t.initUser(stub, args)
	} else if function == "initItem" { //change owner of a specific vehicle part
		return t.initItem(stub, args)
	} else if function == "initTransaction" { //delete a vehicle part
		return t.initTransaction(stub, args)
	}

	// @MODIFY_HERE
	// ==== Write a sub-routine to mark a vehicle part as recalled by ".Name"

	// @MODIFY_HERE
	// ==== Write a sub-routine to mark a vehicle as recalled by ".Manufacturer" & ".Model"

	fmt.Println("invoke did not find func: " + function) //error
	return shim.Error("Received unknown function invocation")
}

// ============================================================
// initLedgerA - sets the initial state of the ledger
// ============================================================
func (t *AutoTraceChaincode) initLedgerA(stub shim.ChaincodeStubInterface) (string, error) {
	// ==== Input sanitation ====
	fmt.Println("- start init initLedgerA")
	var err error

	parts := []vehiclePart{
		vehiclePart{SerialNumber: "abg1234", Assembler: "parts supplier a", AssemblyDate: 1502688979, Name: "airbag 2020", Owner: "parts supplier a"},
		vehiclePart{SerialNumber: "abg1235", Assembler: "parts supplier a", AssemblyDate: 1502688979, Name: "airbag 2020", Owner: "parts supplier a"},
		vehiclePart{SerialNumber: "abg1236", Assembler: "parts supplier b", AssemblyDate: 1502688979, Name: "airbag 2020", Owner: "parts supplier b"},
		vehiclePart{SerialNumber: "abg1237", Assembler: "parts supplier b", AssemblyDate: 1502688979, Name: "airbag 2020", Owner: "parts supplier b"},
		vehiclePart{SerialNumber: "eng1234", Assembler: "parts supplier a", AssemblyDate: 1502688979, Name: "engine 3000", Owner: "parts supplier a"},
		vehiclePart{SerialNumber: "eng1235", Assembler: "parts supplier b", AssemblyDate: 1502688979, Name: "engine 3000", Owner: "parts supplier b"},
		vehiclePart{SerialNumber: "abg1238", Assembler: "sub assembly a", AssemblyDate: 1502688979, Name: "airbag 2020", Owner: "sub assembly a"},
		vehiclePart{SerialNumber: "eng1236", Assembler: "awesome car company", AssemblyDate: 1502688979, Name: "engine 3000", Owner: "awesome car company"},
		vehiclePart{SerialNumber: "sb1234", Assembler: "awesome car company", AssemblyDate: 1502688979, Name: "seat belt 101", Owner: "awesome car company"},
	}

	// add to ledger
	indexName := "assembler~serialNumber"
	ownersIndex := "owner~identifier"

	i := 0
	for i < len(parts) {
		partsAsBytes, _ := json.Marshal(parts[i])
		stub.PutState(parts[i].SerialNumber, partsAsBytes)
		// create indexes
		err = t.createIndex(stub, indexName, []string{parts[i].Assembler, parts[i].SerialNumber})
		if err != nil {
			return "Failed to create Index", err
		}
		err = t.createIndex(stub, ownersIndex, []string{parts[i].Owner, parts[i].SerialNumber})
		if err != nil {
			return "Failed to create Index", err
		}

		fmt.Println("Added", parts[i])
		i = i + 1
	}

	cars := []vehicle{
		vehicle{ChassisNumber: "chas00001", Manufacturer: "awesome car company", Model: "desperado turbo", AssemblyDate: 1502688979, AirbagSerialNumber: "", Owner: "awesome car company"},
		vehicle{ChassisNumber: "chas00002", Manufacturer: "awesome car company", Model: "desperado standard", AssemblyDate: 1502688979, AirbagSerialNumber: "", Owner: "awesome car company"},
		vehicle{ChassisNumber: "chas00003", Manufacturer: "awesome car company", Model: "desperado xl", AssemblyDate: 1502688979, AirbagSerialNumber: "", Owner: "awesome car company"},
	}

	indexName = "manufacturer~chassisNumber"

	i = 0
	for i < len(cars) {
		carsAsBytes, _ := json.Marshal(cars[i])
		stub.PutState(cars[i].ChassisNumber, carsAsBytes)
		// create index
		err = t.createIndex(stub, indexName, []string{cars[i].Manufacturer, cars[i].ChassisNumber})
		if err != nil {
			return "Failed to create Index", err
		}
		err = t.createIndex(stub, ownersIndex, []string{cars[i].Owner, cars[i].ChassisNumber})
		if err != nil {
			return "Failed to create Index", err
		}
		fmt.Println("Added", cars[i])
		i = i + 1
	}

	fmt.Println("- end init initLedgerA")
	return "", nil
}

// ============================================================
// initLedgerB - sets the initial state of the ledger
// ============================================================
func (t *AutoTraceChaincode) initLedgerB(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	fmt.Println("- start init initLedgerB")

	// airbags to sub assembly and manufacturer
	var partsToTransfer = [7][3]string{{"abg1234", "parts supplier a", "sub assembly a"},
		{"abg1235", "parts supplier a", "awesome car company"},
		{"abg1236", "parts supplier b", "sub assembly a"},
		{"abg1237", "parts supplier b", "awesome car company"},
		{"abg1238", "sub assembly a", "awesome car company"},
		// engines to manufacturer
		{"eng1234", "parts supplier a", "awesome car company"},
		{"eng1235", "parts supplier b", "awesome car company"},
	}

	i := 0
	for i < len(partsToTransfer) {
		message, err := t.transferPartHelper(stub, partsToTransfer[i][0], partsToTransfer[i][1], partsToTransfer[i][2])
		if err != nil {
			return shim.Error(err.Error())
		} else if message != "" {
			return shim.Error(message)
		}
		fmt.Println("Transfered Part", partsToTransfer[i])
		i = i + 1
	}

	fmt.Println("- end init initLedgerB")
	return shim.Success(nil)
}

// ============================================================
// initLedgerC - sets the initial state of the ledger
// ============================================================
func (t *AutoTraceChaincode) initLedgerC(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	fmt.Println("- start init initLedgerC")

	// transfer one more airbag to manufacturer
	message, err := t.transferPartHelper(stub, "abg1234", "sub assembly a", "awesome car company")
	if err != nil {
		return shim.Error(err.Error())
	} else if message != "" {
		return shim.Error(message)
	}
	fmt.Println("Transfered Part abg1234, awesome car company")

	// transfer airbags to vehicles
	var transfers = [3][2]string{{"abg1237", "chas00001"},
		{"abg1238", "chas00002"},
		{"abg1235", "chas00003"},
	}

	i := 0
	for i < len(transfers) {
		message, err = t.transferPartToVehicleHelper(stub, transfers[i][0], transfers[i][1])
		if err != nil {
			return shim.Error(err.Error())
		} else if message != "" {
			return shim.Error(message)
		}
		fmt.Println("Transfered Part to Vehicle: ", transfers[i])
		i = i + 1
	}

	fmt.Println("- end init initLedgerC")
	return shim.Success(nil)
}

// ============================================================
// initLedgerD - sets the initial state of the ledger
// ============================================================
func (t *AutoTraceChaincode) initLedgerD(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	fmt.Println("- start init initLedgerD")

	// cars to dealerships
	var carsToTransfer = [2][3]string{{"chas00001", "awesome car company", "cheap as chips dealership"},
		{"chas00002", "awesome car company", "happy camper dealership"},
	}

	i := 0
	for i < len(carsToTransfer) {
		message, err := t.trannsferVehicleHelper(stub, carsToTransfer[i][0], carsToTransfer[i][1], carsToTransfer[i][2])
		if err != nil {
			return shim.Error(err.Error())
		} else if message != "" {
			return shim.Error(message)
		}
		fmt.Println("Transfered Car", carsToTransfer[i])
		i = i + 1
	}

	fmt.Println("- end init initLedgerD")
	return shim.Success(nil)
}


// ============================================================
// initUser - create a new user, store into chaincode state
// ============================================================
func (t *AutoTraceChaincode) initUser(stub shim.ChaincodeStubInterface, args []string) pb.Response {
    var err error

    // data model without recall fields
    //   0           1              2             3                4
    // "ser1234", "tata", "1502688979", "airbag 2020", "aaimler ag / mercedes"

    // data model with recall fields
    //   0           1              2             3                4                        5      6
    // "ser1234", "tata", "1502688979", "airbag 2020", "aaimler ag / mercedes", "false", "0"

    // @MODIFY_HERE extend to expect 7 arguements, up from 5
    if len(args) != 8 {
        return shim.Error("Incorrect number of arguments. Expecting 8")
    }

    // ==== Input sanitation ====
    fmt.Println("- start init user part")
    if len(args[0]) <= 0 {
        return shim.Error("1st argument must be a non-empty string")
    }
    if len(args[1]) <= 0 {
        return shim.Error("2nd argument must be a non-empty string")
    }
    if len(args[3]) <= 0 {
        return shim.Error("4th argument must be a non-empty string")
    }
    if len(args[4]) <= 0 {
        return shim.Error("5th argument must be a non-empty string")
    }

    name := strings.ToLower(args[0])
    userId := args[1]
    email := args[2]
    creditScore, err := strconv.Atoi(args[3])
    if err != nil {
        return shim.Error("4rd argument must be a numeric string")
    }
    latitude := strconv.ParseFloat(args[4], 64)
    longitude := strconv.ParseFloat(args[5], 64)
    contactNumber := args[6]
    rating := strconv.ParseFloat(args[7], 64)

    // ==== Check if vehicle part already exists ====
    userAsBytes, err := stub.GetState(userId)
    if err != nil {
        return shim.Error("Failed to get user: " + err.Error())
    } else if userAsBytes != nil {
        fmt.Println("This user already exists: " + userId)
        return shim.Error("This user already exists: " + userId)
    }

    // @MODIFY_HERE parts recall fields
    // ==== Create user object and marshal to JSON ====
    objectType := "user"
    //vehiclePart := &vehiclePart{objectType, serialNumber, assembler, assemblyDate, name, owner}
    user := &user{objectType, name, userId, email, creditScore, latitude, longitude, contactNumber, rating}
    UserJSONasBytes, err := json.Marshal(user)
    if err != nil {
        return shim.Error(err.Error())
    }

    // === Save vehiclePart to state ===
    err = stub.PutState(userId, UserJSONasBytes)
    if err != nil {
        return shim.Error(err.Error())
    }

    //  ==== Index the vehicle parts to enable assember & owner-based range queries, e.g. return all tata parts ====
    //  An 'index' is a normal key/value entry in state.
    //  The key is a composite key, with the elements that you want to range query on listed first.
    //  In our case, the composite key is based on indexName~assember~serialNumber.
    //  This will enable very efficißent state range queries based on composite keys matching indexName~color~*
    
    
    // ==== Vehicle part saved and indexed. Return success ====
    fmt.Println("- end init user part")
    return shim.Success(nil)
}



// ============================================================
// initItem - create a new item , store into chaincode state
// ============================================================
func (t *AutoTraceChaincode) initItem(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	var err error

	// data model without recall fields
	//   0       		1      		2     		3			   4		5
	// "mer1000001", "mercedes", "c class", "1502688979", "ser1234", "mercedes"

	// data model with recall fields
	//   0       		1      		2     		3			   4		5	       6			7
	// "mer1000001", "mercedes", "c class", "1502688979", "ser1234", "mercedes", "false", "1502688979"

	// @MODIFY_HERE extend to expect 8 arguements, up from 6
	if len(args) != 18 {
		return shim.Error("Incorrect number of arguments. Expecting 18")
	}

	// ==== Input sanitation ====
	fmt.Println("- start init vehicle")
	/*
	if len(args[0]) <= 0 {
		return shim.Error("1st argument must be a non-empty string")
	}
	if len(args[1]) <= 0 {
		return shim.Error("2nd argument must be a non-empty string")
	}
	if len(args[2]) <= 0 {
		return shim.Error("3rd argument must be a non-empty string")
	}
	if len(args[4]) <= 0 {
		return shim.Error("5th argument must be a non-empty string")
	}
	if len(args[5]) <= 0 {
		return shim.Error("6th argument must be a non-empty string")
	}
	*/
	
	
	name := args[0]
	id := args[1]
	type := args[2]
	weight,err := strconv.ParseFloat(args[3],64)
	if err != nil {
		return shim.Error("weight must be a float string")
	}
	brand := args[4]
	model := args[5]
	manufactureYear,err := strconv.Atoi(args[6])
	if err != nil {
		return shim.Error("manufacture year must be a numeric string")
	}
	lenderId := args[7]
	renterId := args[8]
	lat,err := strconv.ParseFloat(args[9],64)
	if err != nil {
		return shim.Error("lat must be a float string")
	}
	lang,err := strconv.ParseFloat(args[10],64)
	if err != nil {
		return shim.Error("lang must be a float string")
	}
	isActive,err := strconv.ParseBool(args[11])
	if err != nil {
		return shim.Error("isActive must be a boolean string")
	}
	rating,err := strconv.ParseFloat(args[12],64)
	if err != nil {
		return shim.Error("rating must be a float string")
	}
	pricePerday := strconv.ParseFloat(args[13],64)
	if err != nil {
		return shim.Error("pricePerday must be a float string")
	}
	imageHash := args[14]
	timeRented,err := strconv.Atoi(args[15])
	if err != nil {
		return shim.Error("timeRented must be a numeric string")
	}
	timeReturned,err :=	strconv.Atoi(args[16])
	if err != nil {
		return shim.Error("timeReturned must be a numeric string")
	}
	currentTransactionId := args[17]
	

	// ==== Check if vehicle already exists ====
	itemAsBytes, err := stub.GetState(id)
	if err != nil {
		return shim.Error("Failed to get vehicle: " + err.Error())
	} else if itemAsBytes != nil {
		return shim.Error("This vehicle already exists: " + id)
	}

	// @MODIFY_HERE parts recall fields
	// ==== Create item object and marshal to JSON ====
	objectType := "item"
	//vehicle := &vehicle{objectType, chassisNumber, manufacturer, model, assemblyDate, airbagSerialNumber, owner}
	item := &item{objectType, name,id,type,weight,brand,model,manufactureYear,lenderId,renterId,lat,lang,isActive,rating,pricePerday,imageHash,timeRented,timeReturned,currentTransactionId}
	itemJSONasBytes, err := json.Marshal(item)
	if err != nil {
		return shim.Error(err.Error())
	}

	// === Save vehicle to state ===
	err = stub.PutState(id, itemJSONasBytes)
	if err != nil {
		return shim.Error(err.Error())
	}
	//  ==== Index the vehicle parts to enable assember & owner-based range queries, e.g. return all tata parts ====
	//  An 'index' is a normal key/value entry in state.
	//  The key is a composite key, with the elements that you want to range query on listed first.
	//  In our case, the composite key is based on indexName~assember~chassisNumber.
	//  This will enable very efficient state range queries based on composite keys matching indexName~color~*
	indexRenter := "renterId~id"
	indexType := "type~id"
	err = t.createIndex(stub, indexRenter, []string{item.renterId, item.id})
	if err != nil {
		return shim.Error(err.Error())
	}
	err = t.createIndex(stub, indexType, []string{item.type, item.id})
	if err != nil {
		return shim.Error(err.Error())
	}

	// ==== Vehicle part saved and indexed. Return success ====
	fmt.Println("- end init item")
	return shim.Success(nil)
}

func (t *AutoTraceChaincode) initTransaction(stub shim.ChaincodeStubInterface, args []string) pb.Response {
    var err error

    // data model without recall fields
    //   0               1              2             3               4        5
    // "mer1000001", "mercedes", "c class", "1502688979", "ser1234", "mercedes"

    // data model with recall fields
    //   0               1              2             3               4        5           6            7
    // "mer1000001", "mercedes", "c class", "1502688979", "ser1234", "mercedes", "false", "1502688979"

    // @MODIFY_HERE extend to expect 8 arguements, up from 6
    
    if len(args) != 12 {
        return shim.Error("Incorrect number of arguments. Expecting 12")
    }

    // ==== Input sanitation ====
    fmt.Println("- start init Transaction")
    if len(args[0]) <= 0 {
        return shim.Error("1st argument must be a non-empty string")
    }
    if len(args[1]) <= 0 {
        return shim.Error("2nd argument must be a non-empty string")
    }
    if len(args[2]) <= 0 {
        return shim.Error("3rd argument must be a non-empty string")
    }
    if len(args[4]) <= 0 {
        return shim.Error("5th argument must be a non-empty string")
    }
    if len(args[5]) <= 0 {
        return shim.Error("6th argument must be a non-empty string")
    }

    transactionId := args[0]
    renterId := args[1]
    lenderId := args[2]
    itemId := args[3]
    startTime, err = strconv.Atoi(args[4])
        if err != nil {
        return shim.Error("5th argument must be a numeric string")
    }

    startTime, err = strconv.Atoi(args[5])
        if err != nil {
        return shim.Error("6th argument must be a numeric string")
    }

    beforeImageURL := args[6]
    afterImageURL := args[7]
    transactionCost := strconv.ParseFloat(args[8], 64)
    isLeaseBroken, err := strconv.ParseBool(args[9])
    if err != nil {
        return shim.Error("10th argument must be a boolean string")
    }
    
    isInsuranceOpted, err := strconv.ParseBool(args[10])
    if err != nil {
        return shim.Error("11th argument must be a boolean string")
    }
    extraCost := strconv.ParseFloat(args[11], 64)

    // ==== Check if vehicle already exists ====
    transactionAsBytes, err := stub.GetState(transactionId)
    if err != nil {
        return shim.Error("Failed to get transaction: " + err.Error())
    } else if transactionAsBytes != nil {
        return shim.Error("This transaction already exists: " + transactionId)
    }

    // @MODIFY_HERE parts recall fields
    // ==== Create vehicle object and marshal to JSON ====
    objectType := "transaction"
    //vehicle := &vehicle{objectType, chassisNumber, manufacturer, model, assemblyDate, airbagSerialNumber, owner}
    transaction := &transaction{objectType, transactionId, renterId, lenderId, itemId, startTime, endTime, beforeImageURL, afterImageURL, transactionCost, isLeaseBroken, isInsuranceOpted, extraCost}
    transactionJSONasBytes, err := json.Marshal(vehicle)
    if err != nil {
        return shim.Error(err.Error())
    }

    // === Save transaction to state ===
    err = stub.PutState(transactionId, transactionJSONasBytes)
    if err != nil {
        return shim.Error(err.Error())
    }
    //  ==== Index the transaction parts to enable assember & owner-based range queries, e.g. return all tata parts ====
    //  An 'index' is a normal key/value entry in state.
    //  The key is a composite key, with the elements that you want to range query on listed first.
    //  In our case, the composite key is based on indexName~assember~chassisNumber.
    //  This will enable very efficient state range queries based on composite keys matching indexName~color~*
    renterIndex := "renter~transactionId"
    lenderIndex := "lender~identifier"
    err = t.createIndex(stub, renterIndex, []string{transaction.renterId, transaction.transactionId})
    if err != nil {
        return shim.Error(err.Error())
    }
    err = t.createIndex(stub, lenderIndex, []string{transaction.lenderId, transaction.transactionId})
    if err != nil {
        return shim.Error(err.Error())
    }

    // ==== transaction part saved and indexed. Return success ====
    fmt.Println("- end init transaction")
    return shim.Success(nil)
}

// ===============================================
// createIndex - create search index for ledger
// ===============================================
func (t *AutoTraceChaincode) createIndex(stub shim.ChaincodeStubInterface, indexName string, attributes []string) error {
	fmt.Println("- start create index")
	var err error
	//  ==== Index the object to enable range queries, e.g. return all parts made by supplier b ====
	//  An 'index' is a normal key/value entry in state.
	//  The key is a composite key, with the elements that you want to range query on listed first.
	//  This will enable very efficient state range queries based on composite keys matching indexName~color~*
	indexKey, err := stub.CreateCompositeKey(indexName, attributes)
	if err != nil {
		return err
	}
	//  Save index entry to state. Only the key name is needed, no need to store a duplicate copy of object.
	//  Note - passing a 'nil' value will effectively delete the key from state, therefore we pass null character as value
	value := []byte{0x00}
	stub.PutState(indexKey, value)

	fmt.Println("- end create index")
	return nil
}

// ===============================================
// deleteIndex - remove search index for ledger
// ===============================================
func (t *AutoTraceChaincode) deleteIndex(stub shim.ChaincodeStubInterface, indexName string, attributes []string) error {
	fmt.Println("- start delete index")
	var err error
	//  ==== Index the object to enable range queries, e.g. return all parts made by supplier b ====
	//  An 'index' is a normal key/value entry in state.
	//  The key is a composite key, with the elements that you want to range query on listed first.
	//  This will enable very efficient state range queries based on composite keys matching indexName~color~*
	indexKey, err := stub.CreateCompositeKey(indexName, attributes)
	if err != nil {
		return err
	}
	//  Delete index by key
	stub.DelState(indexKey)

	fmt.Println("- end delete index")
	return nil
}

// ===============================================
// readUser - read a user from chaincode state
// ===============================================
func (t *AutoTraceChaincode) readUser(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	var userId, jsonResp string
	var err error

	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments. Expecting serial number of the vehicle part to query")
	}

	userId = args[0]
	valAsbytes, err := stub.GetState(userId) //get the user from chaincode state
	if err != nil {
		jsonResp = "{\"Error\":\"Failed to get state for " + userId + "\"}"
		fmt.Println(jsonResp)
		return shim.Error(jsonResp)
	} else if valAsbytes == nil {
		jsonResp = "{\"Error\":\"Vehicle part does not exist: " + userId + "\"}"
		fmt.Println(jsonResp)
		return shim.Error(jsonResp)
	}

	return shim.Success(valAsbytes)
}

// ===============================================
// readItem - read a item from chaincode state
// ===============================================
func (t *AutoTraceChaincode) readItem(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	var id, jsonResp string
	var err error

	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments. Expecting id number of the vehicle to query")
	}

	id = args[0]
	valAsbytes, err := stub.GetState(id) //get the item from chaincode state
	if err != nil {
		jsonResp = "{\"Error\":\"Failed to get state for " + id + "\"}"
		return shim.Error(jsonResp)
	} else if valAsbytes == nil {
		jsonResp = "{\"Error\":\"Vehicle does not exist: " + id + "\"}"
		return shim.Error(jsonResp)
	}

	return shim.Success(valAsbytes)
}

// readTransaction - read a transaction from chaincode state
// ===============================================
func (t *AutoTraceChaincode) readTransaction(stub shim.ChaincodeStubInterface, args []string) pb.Response {
   var transactionId, jsonResp string
   var err error

   if len(args) != 1 {
       return shim.Error("Incorrect number of arguments. Expecting transaction Id of the vehicle part to query")
   }

   transactionId = args[0]
   valAsbytes, err := stub.GetState(transactionId) //get the transaction from chaincode state
   if err != nil {
       jsonResp = "{\"Error\":\"Failed to get state for " + transactionId + "\"}"
       fmt.Println(jsonResp)
       return shim.Error(jsonResp)
   } else if valAsbytes == nil {
       jsonResp = "{\"Error\":\"Vehicle part does not exist: " + transactionId + "\"}"
       fmt.Println(jsonResp)
       return shim.Error(jsonResp)
   }

   return shim.Success(valAsbytes)
}

// ==================================================
// deleteVehiclePart - remove a vehiclePart key/value pair from state
// ==================================================
func (t *AutoTraceChaincode) deleteVehiclePart(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	var jsonResp string
	var vehiclePartJSON vehiclePart
	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}
	serialNumber := args[0]

	// to maintain the assember~serialNumber index, we need to read the vehiclePart first and get its assembler
	valAsbytes, err := stub.GetState(serialNumber) //get the vehiclePart from chaincode state
	if err != nil {
		jsonResp = "{\"Error\":\"Failed to get state for " + serialNumber + "\"}"
		return shim.Error(jsonResp)
	} else if valAsbytes == nil {
		jsonResp = "{\"Error\":\"VehiclePart does not exist: " + serialNumber + "\"}"
		return shim.Error(jsonResp)
	}

	err = json.Unmarshal([]byte(valAsbytes), &vehiclePartJSON)
	if err != nil {
		jsonResp = "{\"Error\":\"Failed to decode JSON of: " + serialNumber + "\"}"
		return shim.Error(jsonResp)
	}

	err = stub.DelState(serialNumber) //remove the vehiclePart from chaincode state
	if err != nil {
		return shim.Error("Failed to delete state:" + err.Error())
	}

	// maintain the index
	indexName := "assembler~serialNumber"
	ownersIndex := "owner~identifier"
	// remove previous indexes
	err = t.deleteIndex(stub, indexName, []string{vehiclePartJSON.Assembler, vehiclePartJSON.SerialNumber})
	if err != nil {
		return shim.Error(err.Error())
	}
	err = t.deleteIndex(stub, ownersIndex, []string{vehiclePartJSON.Owner, vehiclePartJSON.SerialNumber})
	if err != nil {
		return shim.Error(err.Error())
	}

	return shim.Success(nil)
}

// ==================================================
// deleteVehicle - remove a vehicle key/value pair from state
// ==================================================
func (t *AutoTraceChaincode) deleteVehicle(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	var jsonResp string
	var vehicleJSON vehicle
	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}
	chassisNumber := args[0]

	// to maintain the manufacturer~chassisNumber index, we need to read the vehicle first and get its assembler
	valAsbytes, err := stub.GetState(chassisNumber) //get the vehicle from chaincode state
	if err != nil {
		jsonResp = "{\"Error\":\"Failed to get state for " + chassisNumber + "\"}"
		return shim.Error(jsonResp)
	} else if valAsbytes == nil {
		jsonResp = "{\"Error\":\"Vehicle does not exist: " + chassisNumber + "\"}"
		return shim.Error(jsonResp)
	}

	err = json.Unmarshal([]byte(valAsbytes), &vehicleJSON)
	if err != nil {
		jsonResp = "{\"Error\":\"Failed to decode JSON of: " + chassisNumber + "\"}"
		return shim.Error(jsonResp)
	}

	err = stub.DelState(chassisNumber) //remove the vehicle from chaincode state
	if err != nil {
		return shim.Error("Failed to delete state:" + err.Error())
	}

	// maintain the index
	indexName := "manufacturer~chassisNumber"
	ownersIndex := "owner~identifier"
	// remove previous indexes
	err = t.deleteIndex(stub, indexName, []string{vehicleJSON.Manufacturer, vehicleJSON.ChassisNumber})
	if err != nil {
		return shim.Error(err.Error())
	}
	err = t.deleteIndex(stub, ownersIndex, []string{vehicleJSON.Owner, vehicleJSON.ChassisNumber})
	if err != nil {
		return shim.Error(err.Error())
	}

	return shim.Success(nil)
}

// isActive Update when the item is lended
// ===========================================================
func (t *AutoTraceChaincode) updateIsActive(stub shim.ChaincodeStubInterface, args []string) pb.Response {
    //   0       1       3
    // "t_id", "afterImageURL", "actualReturnTime"
    if len(args) < 2 {
        return shim.Error("Incorrect number of arguments. Expecting 2")
    }

    itemId := args[0]
    isActive := strconv.ParseBool(args[1])
    
    fmt.Println("- start update isActive ", itemId, isActive)

    message, err := t.isActiveHelper(stub, itemId, isActive)
    if err != nil {
        return shim.Error(message + err.Error())
    } else if message != "" {
        return shim.Error(message)
    }

    fmt.Println("- end isActive (success)")
    return shim.Success(nil)
}

// ===========================================================
func (t *AutoTraceChaincode) updateTransaction(stub shim.ChaincodeStubInterface, args []string) pb.Response {
    //   0       1       3
    // "t_id", "afterImageURL", "actualReturnTime"
    if len(args) < 3 {
        return shim.Error("Incorrect number of arguments. Expecting 3")
    }

    transactionId := args[0]
    afterImageURL := args[1]
    actualReturnTime := strconv.Atoi(args[2])

    fmt.Println("- start update Transaction ", transactionId, afterImageURL, actualReturnTime)

    message, err := t.transactionUpdateHelper(stub, transactionId, afterImageURL, actualReturnTime)
    if err != nil {
        return shim.Error(message + err.Error())
    } else if message != "" {
        return shim.Error(message)
    }

    fmt.Println("- end update transaction (success)")
    return shim.Success(nil)
}

// ===========================================================
// transferParts : helper method for transferVehiclePart
// ===========================================================
func (t *AutoTraceChaincode) transactionUpdateHelper(stub shim.ChaincodeStubInterface, transactionId string, afterImageURL string, actualReturnTime int) (string, error) {
    // attempt to get the current vehiclePart object by serial number.
    // if sucessful, returns us a byte array we can then us JSON.parse to unmarshal
    fmt.Println("Updating transaction with transaction number: " + transactionId)
    transactionAsBytes, err := stub.GetState(transactionId)
    if err != nil {
        return "Failed to get transaction: " + transactionId, err
    } else if transactionAsBytes == nil {
        return "Transaction does not exist: " + transactionId, nil
    }

    transactionToUpdate := transaction{}
    err = json.Unmarshal(transactionAsBytes, &transactionToUpdate) //unmarshal it aka JSON.parse()
    if err != nil {
        return "", err
    }
/*
    if currentOwner != vehiclePartToTransfer.Owner {
        return "This asset is currently owned by another entity.", err
    }
*/
    transactionToUpdate.actualReturnTime = actualReturnTime //change the actual return time.
    if actualReturnTime > transactionToUpdate.endTime{
        transactionToUpdate.extraCost = 15
        transactionToUpdate.finalTransactionCost = transactionToUpdate.transactionCost + transactionToUpdate.extraCost
    }
    transactionJSONBytes, _ := json.Marshal(transactionToUpdate)
    err = stub.PutState(transactionId, transactionJSONBytes) //rewrite the transaction
    if err != nil {
        return "", err
    }


    // delete old index
    renterIndex := "renter~transactionId"
    lenderIndex := "lender~transactionId" 
    err = t.deleteIndex(stub, renterIndex, []string{transactionToUpdate.renterId, transactionId})
    if err != nil {
        return "", err
    }
    
    err = t.deleteIndex(stub, lenderIndex, []string{transactionToUpdate.lenderId, transactionId})
    if err != nil {
        return "", err
    }

    // make new index
    renterIndex := "renter~transactionId"
    lenderIndex := "lender~transactionId"
    err = t.createIndex(stub, renterIndex, []string{transaction.renterId, transactionId})
    if err != nil {
        return shim.Error(err.Error())
    }
    
    err = t.createIndex(stub, lenderIndex, []string{transaction.lenderId, transactionId})
    if err != nil {
        return shim.Error(err.Error())
    }
    
    return "", nil
    
}


// ===========================================================
// transferParts : helper method for transferVehiclePart
// ===========================================================
func (t *AutoTraceChaincode) isActiveHelper(stub shim.ChaincodeStubInterface, itemId string, isActive bool) (string, error) {
    // attempt to get the current vehiclePart object by serial number.
    // if sucessful, returns us a byte array we can then us JSON.parse to unmarshal
    fmt.Println("Updating isActive with item number: " + itemId)
    isActiveAsBytes, err := stub.GetState(itemId)
    if err != nil {
        return "Failed to get item: " + itemId, err
    } else if isActiveAsBytes == nil {
        return "item does not exist: " + itemId, nil
    }

    isActiveToUpdate := item{}
    err = json.Unmarshal(isActiveAsBytes, &isActiveToUpdate) //unmarshal it aka JSON.parse()
    if err != nil {
        return "", err
    }

    isActiveToUpdate.isActive = isActive //change the actual return time.
    
    isActiveJSONBytes, _ := json.Marshal(isActiveToUpdate)
    err = stub.PutState(itemId, isActiveJSONBytes) //rewrite the transaction
    if err != nil {
        return "", err
    }

    // delete old index
    indexRenter := "renterId~id"
   indexType := "type~id"
   err = t.deleteIndex(stub, indexRenter, []string{isActiveToUpdate.renterId, itemId})
    if err != nil {
        return "", err
    }
    err = t.deleteIndex(stub, indexType, []string{isActiveToUpdate.type, itemId})
    if err != nil {
        return "", err
    }

    // make new index
    renterIndex := "renter~transactionId"
    lenderIndex := "lender~transactionId"
    err = t.createIndex(stub, indexRenter, []string{isActiveToUpdate.renterId, itemId})
    if err != nil {
        return shim.Error(err.Error())
    }
    
    err = t.createIndex(stub, indexType, []string{isActiveToUpdate.type, itemId})
    if err != nil {
        return shim.Error(err.Error())
    }
    
    return "", nil
    
}

// ===========================================================================================
// getVehiclePartByRange performs a range query based on the start and end keys provided.

// Read-only function results are not typically submitted to ordering. If the read-only
// results are submitted to ordering, or if the query is used in an update transaction
// and submitted to ordering, then the committing peers will re-execute to guarantee that
// result sets are stable between endorsement time and commit time. The transaction is
// invalidated by the committing peers if the result set has changed between endorsement
// time and commit time.
// Therefore, range queries are a safe option for performing update transactions based on query results.
// ===========================================================================================
func (t *AutoTraceChaincode) getVehiclePartByRange(stub shim.ChaincodeStubInterface, args []string) pb.Response {

	if len(args) < 2 {
		return shim.Error("Incorrect number of arguments. Expecting 2")
	}

	startKey := args[0]
	endKey := args[1]

	resultsIterator, err := stub.GetStateByRange(startKey, endKey)
	if err != nil {
		return shim.Error(err.Error())
	}
	defer resultsIterator.Close()

	// buffer is a JSON array containing QueryResults
	var buffer bytes.Buffer
	buffer.WriteString("[")

	bArrayMemberAlreadyWritten := false
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return shim.Error(err.Error())
		}
		// Add a comma before array members, suppress it for the first array member
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}
		buffer.WriteString("{\"Key\":")
		buffer.WriteString("\"")
		buffer.WriteString(queryResponse.Key)
		buffer.WriteString("\"")

		buffer.WriteString(", \"Record\":")
		// Record is a JSON object, so we write as-is
		buffer.WriteString(string(queryResponse.Value))
		buffer.WriteString("}")
		bArrayMemberAlreadyWritten = true
	}
	buffer.WriteString("]")

	fmt.Printf("- getVehiclePartByRange queryResult:\n%s\n", buffer.String())

	return shim.Success(buffer.Bytes())
}

// =======Rich queries =========================================================================
// Two examples of rich queries are provided below (parameterized query and ad hoc query).

// Rich queries pass a query string to the state database.
// Rich queries are only supported by state database implementations
//  that support rich query (e.g. CouchDB).
// The query string is in the syntax of the underlying state database.
// With rich queries there is no guarantee that the result set hasn't changed between
//  endorsement time and commit time, aka 'phantom reads'.
// Therefore, rich queries should not be used in update transactions, unless the
// application handles the possibility of result set changes between endorsement and commit time.
// Rich queries can be used for point-in-time queries against a peer.
// ============================================================================================

// ===== Example: Parameterized rich query =================================================
// queryVehiclePartByOwner queries for vehicle part based on a passed in owner.
// This is an example of a parameterized query where the query logic is baked into the chaincode,
// and accepting a single query parameter (owner).
// Only available on state databases that support rich query (e.g. CouchDB)
// =========================================================================================
func (t *AutoTraceChaincode) queryVehiclePartByOwner(stub shim.ChaincodeStubInterface, args []string) pb.Response {

	//   0
	// "bob"
	if len(args) < 1 {
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}

	owner := strings.ToLower(args[0])

	queryString := fmt.Sprintf("{\"selector\":{\"docType\":\"vehiclePart\",\"owner\":\"%s\"}}", owner)

	queryResults, err := getQueryResultForQueryString(stub, queryString)
	if err != nil {
		return shim.Error(err.Error())
	}
	return shim.Success(queryResults)
}

// ===== Example: Ad hoc rich query ========================================================
// queryVehiclePart uses a query string to perform a query for vehiclePart.
// Query string matching state database syntax is passed in and executed as is.
// Supports ad hoc queries that can be defined at runtime by the client.
// If this is not desired, follow the queryVehiclePartByOwner example for parameterized queries.
// Only available on state databases that support rich query (e.g. CouchDB)
// =========================================================================================
func (t *AutoTraceChaincode) queryVehiclePart(stub shim.ChaincodeStubInterface, args []string) pb.Response {

	//   0
	// "queryString"
	if len(args) < 1 {
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}

	queryString := args[0]

	queryResults, err := getQueryResultForQueryString(stub, queryString)
	if err != nil {
		return shim.Error(err.Error())
	}
	return shim.Success(queryResults)
}

// =========================================================================================
// getQueryResultForQueryString executes the passed in query string.
// Result set is built and returned as a byte array containing the JSON results.
// =========================================================================================
func getQueryResultForQueryString(stub shim.ChaincodeStubInterface, queryString string) ([]byte, error) {

	fmt.Printf("- getQueryResultForQueryString queryString:\n%s\n", queryString)

	resultsIterator, err := stub.GetQueryResult(queryString)
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()

	// buffer is a JSON array containing QueryRecords
	var buffer bytes.Buffer
	buffer.WriteString("[")

	bArrayMemberAlreadyWritten := false
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return nil, err
		}
		// Add a comma before array members, suppress it for the first array member
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}
		buffer.WriteString("{\"Key\":")
		buffer.WriteString("\"")
		buffer.WriteString(queryResponse.Key)
		buffer.WriteString("\"")

		buffer.WriteString(", \"Record\":")
		// Record is a JSON object, so we write as-is
		buffer.WriteString(string(queryResponse.Value))
		buffer.WriteString("}")
		bArrayMemberAlreadyWritten = true
	}
	buffer.WriteString("]")

	fmt.Printf("- getQueryResultForQueryString queryResult:\n%s\n", buffer.String())

	return buffer.Bytes(), nil
}

// ===========================================================================================
// getHistoryForRecord returns the histotical state transitions for a given key of a record
// ===========================================================================================
func (t *AutoTraceChaincode) getHistoryForRecord(stub shim.ChaincodeStubInterface, args []string) pb.Response {

	if len(args) < 1 {
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}

	recordKey := args[0]

	fmt.Printf("- start getHistoryForRecord: %s\n", recordKey)

	resultsIterator, err := stub.GetHistoryForKey(recordKey)
	if err != nil {
		return shim.Error(err.Error())
	}
	defer resultsIterator.Close()

	// buffer is a JSON array containing historic values for the key/value pair
	var buffer bytes.Buffer
	buffer.WriteString("[")

	bArrayMemberAlreadyWritten := false
	for resultsIterator.HasNext() {
		response, err := resultsIterator.Next()
		if err != nil {
			return shim.Error(err.Error())
		}
		// Add a comma before array members, suppress it for the first array member
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}
		buffer.WriteString("{\"TxId\":")
		buffer.WriteString("\"")
		buffer.WriteString(response.TxId)
		buffer.WriteString("\"")

		buffer.WriteString(", \"Value\":")
		// if it was a delete operation on given key, then we need to set the
		//corresponding value null. Else, we will write the response.Value
		//as-is (as the Value itself a JSON vehiclePart)
		if response.IsDelete {
			buffer.WriteString("null")
		} else {
			buffer.WriteString(string(response.Value))
		}

		buffer.WriteString(", \"Timestamp\":")
		buffer.WriteString("\"")
		buffer.WriteString(time.Unix(response.Timestamp.Seconds, int64(response.Timestamp.Nanos)).String())
		buffer.WriteString("\"")

		buffer.WriteString(", \"IsDelete\":")
		buffer.WriteString("\"")
		buffer.WriteString(strconv.FormatBool(response.IsDelete))
		buffer.WriteString("\"")

		buffer.WriteString("}")
		bArrayMemberAlreadyWritten = true
	}
	buffer.WriteString("]")

	fmt.Printf("- getHistoryForRecord returning:\n%s\n", buffer.String())

	return shim.Success(buffer.Bytes())
}

// ===========================================================================================
// cryptoVerify : Verifies signed message against public key
// Public Key of Authority:
// [48 78 48 16 6 7 42 134 72 206 61 2 1 6 5 43 129 4 0 33 3 58 0 4 21 162 242 84 40 78 13 26 160 33 97 191 210 22 152 134 162 66 12 77 221 129 138 60 74 243 198 34 102 209 14 48 16 2 98 96 172 47 170 216 228 169 103 121 153 100 84 111 33 13 106 42 46 227 52 91]
// ===========================================================================================
func cryptoVerify(hash []byte, publicKeyBytes []byte, r *big.Int, s *big.Int) (result bool) {
	fmt.Println("- Verifying ECDSA signature")
	fmt.Println("Message")
	fmt.Println(hash)
	fmt.Println("Public Key")
	fmt.Println(publicKeyBytes)
	fmt.Println("r")
	fmt.Println(r)
	fmt.Println("s")
	fmt.Println(s)

	publicKey, err := x509.ParsePKIXPublicKey(publicKeyBytes)
	if err != nil {
		fmt.Println(err.Error())
		return false
	}

	switch publicKey := publicKey.(type) {
	case *ecdsa.PublicKey:
		return ecdsa.Verify(publicKey, hash, r, s)
	default:
		return false
	}
}
